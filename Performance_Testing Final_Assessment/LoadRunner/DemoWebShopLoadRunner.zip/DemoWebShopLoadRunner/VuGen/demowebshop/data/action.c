Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_url("demowebshop.tricentis.com", 
		"URL=https://demowebshop.tricentis.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("Nop.customer=84b5a18b-4592-4657-bcb9-966eb92ddb22; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("ARRAffinity=f4edb6097d47b618727013498965259efd35f8883f487e535625e82c6dc8570c; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("ARRAffinitySameSite=f4edb6097d47b618727013498965259efd35f8883f487e535625e82c6dc8570c; DOMAIN=demowebshop.tricentis.com");

	web_concurrent_start(NULL);

	web_url("jquery-ui-1.10.3.custom.min.css", 
		"URL=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t2.inf", 
		LAST);

	web_url("default.css", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t3.inf", 
		LAST);

	web_url("styles.css", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("responsive.css", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/responsive.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t5.inf", 
		LAST);

	web_url("jquery.validate.unobtrusive.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery.validate.unobtrusive.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t6.inf", 
		LAST);

	web_url("jquery-1.10.2.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery-1.10.2.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t7.inf", 
		LAST);

	web_url("nivo-slider.css", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/nivo-slider.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t8.inf", 
		LAST);

	web_url("public.ajaxcart.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.ajaxcart.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t9.inf", 
		LAST);

	web_url("jquery-migrate-1.2.1.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery-migrate-1.2.1.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t10.inf", 
		LAST);

	web_url("jquery.nivo.slider.js", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Scripts/jquery.nivo.slider.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t11.inf", 
		LAST);

	web_url("public.common.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.common.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t12.inf", 
		LAST);

	web_url("jquery-ui-1.10.3.custom.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery-ui-1.10.3.custom.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t13.inf", 
		LAST);

	web_url("jquery.validate.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery.validate.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t14.inf", 
		LAST);

	web_url("0000224_141-inch-laptop_125.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000224_141-inch-laptop_125.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t15.inf", 
		LAST);

	web_url("0000172_build-your-own-cheap-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000172_build-your-own-cheap-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t16.inf", 
		LAST);

	web_url("0000015_25-virtual-gift-card_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000015_25-virtual-gift-card_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t17.inf", 
		LAST);

	web_url("0000240.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000240.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t18.inf", 
		LAST);

	web_url("0000215.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000215.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t19.inf", 
		LAST);

	web_url("logo.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/logo.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t20.inf", 
		LAST);

	web_url("0000031_build-your-own-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000031_build-your-own-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t27.inf", 
		LAST);

	web_url("0000201_build-your-own-expensive-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000201_build-your-own-expensive-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t28.inf", 
		LAST);

	web_url("0000204_simple-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000204_simple-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t29.inf", 
		LAST);

	web_url("favicon.ico", 
		"URL=https://demowebshop.tricentis.com/favicon.ico", 
		"Resource=1", 
		"RecContentType=image/x-icon", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t30.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_concurrent_start(NULL);

	web_url("star-x-inactive.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/star-x-inactive.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t21.inf", 
		LAST);

	web_url("star-x-active.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/star-x-active.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t22.inf", 
		LAST);

	web_url("loading.gif", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/loading.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Snapshot=t23.inf", 
		LAST);

	web_url("top-menu-divider.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-divider.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t24.inf", 
		LAST);

	web_url("bullet-right.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/bullet-right.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t25.inf", 
		LAST);

	web_url("ui-bg_flat_75_ffffff_40x100.png", 
		"URL=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/images/ui-bg_flat_75_ffffff_40x100.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", 
		"Snapshot=t26.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_concurrent_start(NULL);

	web_url("arrows.png", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/arrows.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Snapshot=t31.inf", 
		LAST);

	web_url("bullets.png", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/bullets.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Snapshot=t32.inf", 
		LAST);

	web_url("top-menu-triangle.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-triangle.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t33.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(31);

	lr_start_transaction("!_navigate");

	lr_end_transaction("!_navigate",LR_AUTO);

	lr_start_transaction("2_login");

	web_url("Log in", 
		"URL=https://demowebshop.tricentis.com/login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t34.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("__utmb=78382081.2.10.1790868183; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("NOPCOMMERCE.AUTH=DF95B90027DB388A77056349411E00FCF5FD2FB0237923BD792A107E35CFD3839CF192A096D80EB7B81518D0E0B87EE8855D8EA6EFD1D5046518EBCAE29C08B3B89217062F72BA7DC6AAAB13901F95602430F51840283E598E32337C6B555352966031B9FE34E9744E259C979F22D96B253B14D597E96E66BC7AF780DA8DE4CB; DOMAIN=demowebshop.tricentis.com");

	web_submit_data("login", 
		"Action=https://demowebshop.tricentis.com/login", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/login", 
		"Snapshot=t35.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=Email", "Value=amal@yaho.com", ENDITEM, 
		"Name=Password", "Value=amukudumku", ENDITEM, 
		"Name=RememberMe", "Value=false", ENDITEM, 
		LAST);

	lr_end_transaction("2_login",LR_AUTO);

	lr_start_transaction("3_searchprod");

	web_add_cookie("__utmb=78382081.3.10.1790868183; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(17);

	web_url("ajax_loader_small.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ajax_loader_small.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t36.inf", 
		LAST);

	web_url("searchtermautocomplete", 
		"URL=https://demowebshop.tricentis.com/catalog/searchtermautocomplete?term=lap", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t37.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("searchtermautocomplete_2", 
		"URL=https://demowebshop.tricentis.com/catalog/searchtermautocomplete?term=laptop", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t38.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("ui-bg_glass_75_dadada_1x400.png", 
		"URL=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/images/ui-bg_glass_75_dadada_1x400.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", 
		"Snapshot=t39.inf", 
		LAST);

	web_url("141-inch-laptop", 
		"URL=https://demowebshop.tricentis.com/141-inch-laptop", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t40.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("NopCommerce.RecentlyViewedProducts=RecentlyViewedProductIds=31; DOMAIN=demowebshop.tricentis.com");

	web_concurrent_start(NULL);

	web_url("magnific-popup.css", 
		"URL=https://demowebshop.tricentis.com/Content/magnific-popup/magnific-popup.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/141-inch-laptop", 
		"Snapshot=t41.inf", 
		LAST);

	web_url("jquery.magnific-popup.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery.magnific-popup.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/141-inch-laptop", 
		"Snapshot=t42.inf", 
		LAST);

	web_url("0000224_141-inch-laptop_300.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000224_141-inch-laptop_300.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/141-inch-laptop", 
		"Snapshot=t43.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("3_searchprod",LR_AUTO);

	lr_start_transaction("4_addtocart");

	web_add_cookie("__utmb=78382081.4.10.1790868183; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(21);

	web_url("ajax_loader_large.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ajax_loader_large.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t44.inf", 
		LAST);

	web_submit_data("1", 
		"Action=https://demowebshop.tricentis.com/addproducttocart/details/31/1", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/141-inch-laptop", 
		"Snapshot=t45.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=addtocart_31.EnteredQuantity", "Value=1", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("0000224_141-inch-laptop_47.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000224_141-inch-laptop_47.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/141-inch-laptop", 
		"Snapshot=t46.inf", 
		LAST);

	web_url("ico-close-notification-bar.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ico-close-notification-bar.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t47.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("4_addtocart",LR_AUTO);

	lr_think_time(17);

	lr_start_transaction("5_viewcart");

	web_url("cart", 
		"URL=https://demowebshop.tricentis.com/cart", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/141-inch-laptop", 
		"Snapshot=t48.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("0000224_141-inch-laptop_80.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000224_141-inch-laptop_80.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t49.inf", 
		LAST);

	lr_end_transaction("5_viewcart",LR_AUTO);

	lr_start_transaction("6_checkout");

	web_add_cookie("__utmb=78382081.5.10.1790868183; DOMAIN=demowebshop.tricentis.com");

	web_submit_data("cart_2", 
		"Action=https://demowebshop.tricentis.com/cart", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t50.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=itemquantity7122994", "Value=1", ENDITEM, 
		"Name=discountcouponcode", "Value=", ENDITEM, 
		"Name=giftcardcouponcode", "Value=", ENDITEM, 
		"Name=CountryId", "Value=5", ENDITEM, 
		"Name=StateProvinceId", "Value=0", ENDITEM, 
		"Name=ZipPostalCode", "Value=736353", ENDITEM, 
		"Name=termsofservice", "Value=on", ENDITEM, 
		"Name=checkout", "Value=checkout", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("public.accordion.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.accordion.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t51.inf", 
		LAST);

	web_url("public.onepagecheckout.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.onepagecheckout.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t52.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("6_checkout",LR_AUTO);

	lr_start_transaction("7_billadd");

	web_add_cookie("__utmb=78382081.6.10.1790868183; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(18);

	web_submit_data("OpcSaveBilling", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveBilling/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t53.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=billing_address_id", "Value=5157670", ENDITEM, 
		"Name=BillingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.FirstName", "Value=amal", ENDITEM, 
		"Name=BillingNewAddress.LastName", "Value=damal", ENDITEM, 
		"Name=BillingNewAddress.Email", "Value=amal@yaho.com", ENDITEM, 
		"Name=BillingNewAddress.Company", "Value=", ENDITEM, 
		"Name=BillingNewAddress.CountryId", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.City", "Value=", ENDITEM, 
		"Name=BillingNewAddress.Address1", "Value=", ENDITEM, 
		"Name=BillingNewAddress.Address2", "Value=", ENDITEM, 
		"Name=BillingNewAddress.ZipPostalCode", "Value=", ENDITEM, 
		"Name=BillingNewAddress.PhoneNumber", "Value=", ENDITEM, 
		"Name=BillingNewAddress.FaxNumber", "Value=", ENDITEM, 
		LAST);

	web_url("arrow-up.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/arrow-up.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t54.inf", 
		LAST);

	lr_end_transaction("7_billadd",LR_AUTO);

	lr_think_time(17);

	lr_start_transaction("8_shipadd");

	web_submit_data("OpcSaveShipping", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShipping/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t55.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=shipping_address_id", "Value=5157670", ENDITEM, 
		"Name=ShippingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.FirstName", "Value=amal", ENDITEM, 
		"Name=ShippingNewAddress.LastName", "Value=damal", ENDITEM, 
		"Name=ShippingNewAddress.Email", "Value=amal@yaho.com", ENDITEM, 
		"Name=ShippingNewAddress.Company", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.CountryId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.City", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address1", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address2", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.ZipPostalCode", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.PhoneNumber", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.FaxNumber", "Value=", ENDITEM, 
		"Name=PickUpInStore", "Value=true", ENDITEM, 
		"Name=PickUpInStore", "Value=false", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("logo.jpg", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.CashOnDelivery/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t56.inf", 
		LAST);

	web_url("logo.jpg_2", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.PurchaseOrder/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t57.inf", 
		LAST);

	web_url("logo.jpg_3", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.Manual/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t58.inf", 
		LAST);

	web_url("logo.jpg_4", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.CheckMoneyOrder/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t59.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("8_shipadd",LR_AUTO);

	lr_start_transaction("9_paymethod");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	lr_think_time(20);

	web_submit_data("OpcSavePaymentMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSavePaymentMethod/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t61.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentmethod", "Value=Payments.CashOnDelivery", ENDITEM, 
		LAST);

	lr_end_transaction("9_paymethod",LR_AUTO);

	lr_think_time(19);

	lr_start_transaction("10_payinfo");

	web_custom_request("OpcSavePaymentInfo", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcSavePaymentInfo/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t62.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	lr_end_transaction("10_payinfo",LR_AUTO);

	lr_start_transaction("11_confirmorder");

	web_add_cookie("ASP.NET_SessionId=yoiq5sjqzgaqfjbgagacoj0o; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(12);

	web_custom_request("OpcConfirmOrder", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcConfirmOrder/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t63.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	web_url("completed", 
		"URL=https://demowebshop.tricentis.com/checkout/completed/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t64.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("11_confirmorder",LR_AUTO);

	return 0;
}