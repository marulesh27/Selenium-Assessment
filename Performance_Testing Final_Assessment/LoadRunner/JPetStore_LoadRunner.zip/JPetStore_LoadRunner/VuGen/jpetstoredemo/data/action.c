Action()
{

	lr_start_transaction("1_navigate");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_url("jpetstore.aspectran.com", 
		"URL=https://jpetstore.aspectran.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("splash.gif", 
		"URL=https://jpetstore.aspectran.com/images/splash.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t2.inf", 
		LAST);

	web_url("logo-topbar.gif", 
		"URL=https://jpetstore.aspectran.com/images/logo-topbar.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t3.inf", 
		LAST);

	web_url("pets.png", 
		"URL=https://petclinic.aspectran.com/images/pets.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t4.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("1_navigate",LR_AUTO);

	lr_think_time(13);

	lr_start_transaction("2_signin");

	web_url("Sign In", 
		"URL=https://jpetstore.aspectran.com/account/signonForm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t5.inf", 
		"Mode=HTTP", 
		LAST);

	web_submit_data("signon", 
		"Action=https://jpetstore.aspectran.com/account/signon", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/account/signonForm", 
		"Snapshot=t8.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=referer", "Value=", ENDITEM, 
		"Name=username", "Value=j2ee", ENDITEM, 
		"Name=password", "Value=j2ee", ENDITEM, 
		LAST);

	web_url("banner_dogs.gif", 
		"URL=https://jpetstore.aspectran.com/images/banner_dogs.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t9.inf", 
		LAST);

	lr_end_transaction("2_signin",LR_AUTO);

	lr_think_time(17);

	lr_start_transaction("3_categories");

	web_url("Dogs", 
		"URL=https://jpetstore.aspectran.com/categories/DOGS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t10.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("3_categories",LR_AUTO);

	lr_think_time(12);

	lr_start_transaction("4_breed");

	web_url("K9-BD-01", 
		"URL=https://jpetstore.aspectran.com/products/K9-BD-01", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/categories/DOGS", 
		"Snapshot=t11.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("4_breed",LR_AUTO);

	lr_think_time(14);

	lr_start_transaction("5_selectprod");

	web_url("EST-33", 
		"URL=https://jpetstore.aspectran.com/products/K9-BD-01/items/EST-33", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/products/K9-BD-01", 
		"Snapshot=t12.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("dog2.gif", 
		"URL=https://jpetstore.aspectran.com/images/dog2.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/products/K9-BD-01/items/EST-33", 
		"Snapshot=t13.inf", 
		LAST);

	lr_end_transaction("5_selectprod",LR_AUTO);

	lr_start_transaction("6_addtocart");

	web_url("Add to Cart", 
		"URL=https://jpetstore.aspectran.com/cart/addItemToCart?itemId=EST-33", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/products/K9-BD-01/items/EST-33", 
		"Snapshot=t14.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("6_addtocart",LR_AUTO);

	lr_think_time(7);

	lr_start_transaction("6_checkout");

	web_url("Proceed to Checkout", 
		"URL=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/cart/viewCart", 
		"Snapshot=t15.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("6_checkout",LR_AUTO);

	lr_think_time(16);

	lr_start_transaction("7_address");

	web_submit_data("newOrder", 
		"Action=https://jpetstore.aspectran.com/order/newOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t16.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentForm", "Value=true", ENDITEM, 
		"Name=billingForm", "Value=true", ENDITEM, 
		"Name=cardType", "Value=Visa", ENDITEM, 
		"Name=creditCard", "Value=999999999999999", ENDITEM, 
		"Name=expiryDate", "Value=12/2019", ENDITEM, 
		"Name=billToFirstName", "Value=Test", ENDITEM, 
		"Name=billToLastName", "Value=User", ENDITEM, 
		"Name=billAddress1", "Value=123 Test St", ENDITEM, 
		"Name=billAddress2", "Value=123 Test St", ENDITEM, 
		"Name=billCity", "Value=Testville", ENDITEM, 
		"Name=billState", "Value=CA", ENDITEM, 
		"Name=billZip", "Value=10001", ENDITEM, 
		"Name=billCountry", "Value=US", ENDITEM, 
		LAST);

	lr_end_transaction("7_address",LR_AUTO);

	lr_start_transaction("8_confirm");

	web_submit_data("submitOrder", 
		"Action=https://jpetstore.aspectran.com/order/submitOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrder", 
		"Snapshot=t17.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=confirmed", "Value=true", ENDITEM, 
		LAST);

	lr_end_transaction("8_confirm",LR_AUTO);

	return 0;
}